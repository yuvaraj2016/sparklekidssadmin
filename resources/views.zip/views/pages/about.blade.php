@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">About Photoz</div>
                <div class='card-body'>
                    This is the About Section.
                    <br><br>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. <br>
                    Reprehenderit laudantium, obcaecati aut quam necessitatibus at numquam animi<br>
                    fugiat perspiciatis magnam sapiente, laborum soluta deleniti. Nemo in libero nobis excepturi ea.

                    <br><br>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. <br>
                    Reprehenderit laudantium, obcaecati aut quam necessitatibus at numquam animi<br>
                    fugiat perspiciatis magnam sapiente, laborum soluta deleniti. Nemo in libero nobis excepturi ea.
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
